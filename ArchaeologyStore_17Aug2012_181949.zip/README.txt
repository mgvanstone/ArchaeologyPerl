##Open a command window with Windows administrator permission
#Start a All Programs -> DB7Devaccess -> Developer Access -> Open Elevated Command Window
#Use this command window to run all your commands

##Download
#Unzip all files from Archaeology Archaeology_v_0_1.zip into C:\archaeology

##Create tables
#Use Toad to connect to the Archaeology database and run ddl.sql

##To sync the config and start the parsing script, open a command prompt
## and run this batch file (and entering the p4 password when prompted)
c:
cd \archaeology
start.bat

##Create views 
#Use Toad to connect to the Archaeology database and run view_ddl_v6.sql

